@NonNullApi
package net.jqwik.api.constraints;

import net.jqwik.api.*;