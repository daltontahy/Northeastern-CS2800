@NonNullApi
package net.jqwik.api.arbitraries;

import net.jqwik.api.*;