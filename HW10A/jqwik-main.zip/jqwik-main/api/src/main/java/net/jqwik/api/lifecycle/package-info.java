@NonNullApi
package net.jqwik.api.lifecycle;

import net.jqwik.api.*;