package net.jqwik;

import net.jqwik.api.*;

class MakeGradleHappyTests {

	@Example
	void makeGradleHappy() {
		// This test is only here to get rid of a Gradle warning
	}
}
