## Overview

_Formulate the problem / feature your pull request is aiming at_

### Details

_Give any necessary details about your code that is not obvious from the code itself._

_List open issues and remaining problems with your solution._

---

I hereby agree to the terms of the [jqwik Contributor Agreement](https://github.com/jqwik-team/jqwik/blob/master/CONTRIBUTING.md#jqwik-contributor-agreement).
