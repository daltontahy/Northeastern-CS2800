@NonNullApi
@API(status = INTERNAL)
package net.jqwik.api.support;

import org.apiguardian.api.*;

import net.jqwik.api.*;

import static org.apiguardian.api.API.Status.*;