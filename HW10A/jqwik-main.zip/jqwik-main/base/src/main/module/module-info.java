module net.jqwik {
    requires transitive net.jqwik.api;
	requires transitive net.jqwik.engine;
	requires transitive net.jqwik.time;
	requires transitive net.jqwik.web;
}
