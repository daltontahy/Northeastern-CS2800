@NonNullApi
package net.jqwik.api.statistics;

import net.jqwik.api.*;