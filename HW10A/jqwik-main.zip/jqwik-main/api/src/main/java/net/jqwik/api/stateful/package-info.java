@NonNullApi
package net.jqwik.api.stateful;

import net.jqwik.api.*;