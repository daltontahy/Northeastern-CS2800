package net.jqwik.docs.contracts.eurocalc;

public @interface ContractFor {

	Class value();

	@interface Require {

	}

	@interface Ensure {

	}

	@interface Invariant {

	}
}
