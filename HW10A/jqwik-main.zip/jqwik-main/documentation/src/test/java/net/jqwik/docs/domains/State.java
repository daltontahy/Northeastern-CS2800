package net.jqwik.docs.domains;

public enum State {

	AL, AK, CA, FL, HI, MA, MI, MN, NE, OR, TX, UT, WA
}
