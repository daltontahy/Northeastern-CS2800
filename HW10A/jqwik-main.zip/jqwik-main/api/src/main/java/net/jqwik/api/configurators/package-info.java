@NonNullApi
package net.jqwik.api.configurators;

import net.jqwik.api.*;