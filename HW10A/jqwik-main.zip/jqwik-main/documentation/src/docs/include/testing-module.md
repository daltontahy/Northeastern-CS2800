This module's artefact name is `jqwik-testing`. It provides a few helpful methods
and classes for generator writers to test their generators - including 
edge cases and shrinking.

This module is _not_ in jqwik's default dependencies. It's usually added as a
test-implementation dependency.

