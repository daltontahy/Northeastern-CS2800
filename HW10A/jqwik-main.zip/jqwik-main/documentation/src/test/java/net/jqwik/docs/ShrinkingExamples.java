package net.jqwik.docs;

import java.util.*;

import net.jqwik.api.*;
import net.jqwik.api.constraints.*;

import static java.util.Collections.*;

class ShrinkingExamples {

	@Property(afterFailure = AfterFailureMode.RANDOM_SEED)
	@Report(Reporting.FALSIFIED)
	boolean stringShouldBeShrunkToAA(@ForAll @AlphaChars String aString) {
		return aString.length() > 5 || aString.length() < 2;
	}

	@Property(afterFailure = AfterFailureMode.RANDOM_SEED)
	@Report(Reporting.FALSIFIED)
		// Should shrink to 46341 - the smallest number whose square is bigger than Integer.MAX_VALUE
	boolean rootOfSquareShouldBeOriginalValue(@Positive @ForAll int anInt) {
		Assume.that(anInt != Integer.MAX_VALUE);
		int square = anInt * anInt;
		return Math.sqrt(square) == anInt;
	}

	static <E> List<E> brokenReverse(List<E> aList) {
		if (aList.size() < 4) {
			aList = new ArrayList<>(aList);
			reverse(aList);
		}
		return aList;
	}

	@Property(afterFailure = AfterFailureMode.RANDOM_SEED)
	boolean reverseShouldSwapFirstAndLast(@ForAll List<Integer> aList) {
		Assume.that(!aList.isEmpty());
		List<Integer> reversed = brokenReverse(aList);
		return aList.get(0).equals(reversed.get(aList.size() - 1));
	}

	@Property(afterFailure = AfterFailureMode.RANDOM_SEED)
	boolean reverseShouldSwapFirstAndLast_Wildcard(@ForAll List<?> aList) {
		Assume.that(!aList.isEmpty());
		List<?> reversed = brokenReverse(aList);
		return aList.get(0).equals(reversed.get(aList.size() - 1));
	}

	@Property(generation = GenerationMode.RANDOMIZED)
	@Report(Reporting.FALSIFIED)
	boolean shouldShrinkTo101(@ForAll("numberStrings") String aNumberString) {
		return Integer.parseInt(aNumberString) % 2 == 0;
	}

	@Provide
	Arbitrary<String> numberStrings() {
		return Arbitraries.integers().between(100, 1000).map(String::valueOf);
	}

}
