@NonNullApi
package net.jqwik.api.state;

import net.jqwik.api.NonNullApi;