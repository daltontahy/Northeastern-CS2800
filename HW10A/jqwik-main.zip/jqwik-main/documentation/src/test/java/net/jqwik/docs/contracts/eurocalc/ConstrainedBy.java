package net.jqwik.docs.contracts.eurocalc;

public @interface ConstrainedBy {

	Class<?> value();
}
