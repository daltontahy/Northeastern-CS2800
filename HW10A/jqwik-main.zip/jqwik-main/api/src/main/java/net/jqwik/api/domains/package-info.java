@NonNullApi
package net.jqwik.api.domains;

import net.jqwik.api.*;