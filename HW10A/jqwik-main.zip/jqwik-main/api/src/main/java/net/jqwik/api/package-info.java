@NonNullApi
package net.jqwik.api;