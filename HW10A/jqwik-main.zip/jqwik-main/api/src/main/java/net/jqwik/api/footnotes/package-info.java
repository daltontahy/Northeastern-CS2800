@NonNullApi
package net.jqwik.api.footnotes;

import net.jqwik.api.*;